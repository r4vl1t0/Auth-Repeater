# Auth Repeater MVP 0.2.0

Burp Suite Community/Professional extension for manually replaying one selected HTTP request under multiple configured identities.

## MVP features

- Custom Burp tab: **Auth Repeater**
- **Set Environment**:
  - URL-prefix scope
  - 3 configurable users
  - each user can define one or more identity headers
  - supports `Cookie`, `Authorization`, and custom headers
- Context menu: **Send to Auth Repeater**
- Replays the same method, URL, query string and body for each enabled identity
- Removes inherited authentication headers before applying each identity
- Results log:
  - Run
  - User
  - Method
  - URL
  - HTTP status
  - Response length
  - Time
- Request/Response inspector:
  - select any result row
  - shows the exact replayed request after identity replacement
  - shows the exact HTTP response received
  - uses Burp native read-only HTTP message editors

## Build

PortSwigger currently requires extensions to target Java 21 or lower.

This project targets Java 21 and Montoya API 2026.7.

### IntelliJ

1. Open this folder as a Gradle project.
2. Configure a JDK 21 (recommended by PortSwigger).
3. Run the Gradle `jar` task.
4. The extension JAR will be created under:

   `build/libs/auth-repeater-mvp-0.2.0.jar`

### Command line

With Gradle installed:

```bash
gradle clean jar
```

## Load into Burp

1. Open Burp Suite.
2. Go to **Extensions > Installed**.
3. Click **Add**.
4. Select extension type **Java**.
5. Select `build/libs/auth-repeater-mvp-0.2.0.jar`.

## Configure the lab

Example scope:

```text
http://127.0.0.1:5000
```

Example identities:

### Master

```text
Cookie: session=<MASTER_SESSION_COOKIE>
```

### Assistant

```text
Cookie: session=<ASSISTANT_SESSION_COOKIE>
```

### Viewer

```text
Cookie: session=<VIEWER_SESSION_COOKIE>
```

JWT/API style authentication works too:

```text
Authorization: Bearer eyJ...
X-Tenant-ID: 123
```

Press **Save Environment**.

Then right-click a request in Proxy HTTP history or an HTTP message editor and select:

`Send to Auth Repeater`

## Important MVP behavior

The same request body is sent for every identity. Requests that create/update/delete state can affect later replays. For example, replaying `POST /api/users/create` may create the user for the first identity and return `409` for later identities because the username already exists. This is an application side-effect, not necessarily an authorization decision.

For initial validation, use read-only endpoints such as `GET /api/users`, `GET /api/activity`, and `GET /api/inventory`.
