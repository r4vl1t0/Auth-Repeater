import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.persistence.Preferences;
import burp.api.montoya.ui.editor.EditorOptions;
import burp.api.montoya.ui.editor.HttpRequestEditor;
import burp.api.montoya.ui.editor.HttpResponseEditor;
import burp.api.montoya.ui.contextmenu.ContextMenuEvent;
import burp.api.montoya.ui.contextmenu.ContextMenuItemsProvider;
import burp.api.montoya.ui.contextmenu.MessageEditorHttpRequestResponse;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class Extension implements BurpExtension, ContextMenuItemsProvider {

    private static final String EXTENSION_NAME = "Auth Repeater MVP";

    private MontoyaApi api;
    private Preferences preferences;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicInteger runCounter = new AtomicInteger(0);

    private JPanel mainPanel;
    private JTextField scopeField;
    private JLabel environmentStatus;

    private final List<UserEditor> userEditors = new ArrayList<>();

    private DefaultTableModel resultsModel;
    private JTable resultsTable;
    private HttpRequestEditor requestViewer;
    private HttpResponseEditor responseViewer;
    private final List<ResultEntry> resultEntries = new ArrayList<>();

    // Snapshot used by the repeater after pressing "Save Environment".
    private volatile Environment environment;

    @Override
    public void initialize(MontoyaApi montoyaApi) {
        this.api = montoyaApi;
        this.preferences = api.persistence().preferences();

        api.extension().setName(EXTENSION_NAME);
        api.extension().registerUnloadingHandler(worker::shutdownNow);

        SwingUtilities.invokeLater(() -> {
            buildUi();
            loadSavedEnvironment();
            api.userInterface().registerSuiteTab("Auth Repeater", mainPanel);
        });

        api.userInterface().registerContextMenuItemsProvider(this);
        api.logging().logToOutput(EXTENSION_NAME + " loaded.");
    }

    @Override
    public List<Component> provideMenuItems(ContextMenuEvent event) {
        HttpRequest request = requestFrom(event);

        if (request == null) {
            return List.of();
        }

        JMenuItem item = new JMenuItem("Send to Auth Repeater");
        item.addActionListener(e -> submitRequest(request));

        return List.of(item);
    }

    private HttpRequest requestFrom(ContextMenuEvent event) {
        List<HttpRequestResponse> selected = event.selectedRequestResponses();

        if (!selected.isEmpty()) {
            return selected.get(0).request();
        }

        return event.messageEditorRequestResponse()
                .map(MessageEditorHttpRequestResponse::requestResponse)
                .map(HttpRequestResponse::request)
                .orElse(null);
    }

    private void buildUi() {
        mainPanel = new JPanel(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Set Environment", buildEnvironmentPanel());
        tabs.addTab("Results Log", buildResultsPanel());

        mainPanel.add(tabs, BorderLayout.CENTER);
    }

    private JPanel buildEnvironmentPanel() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel scopePanel = new JPanel(new BorderLayout(8, 8));
        scopePanel.setBorder(BorderFactory.createTitledBorder("Scope"));

        scopeField = new JTextField();
        scopeField.setToolTipText("Example: http://127.0.0.1:5000");

        JLabel scopeHelp = new JLabel("URL prefix, for example: http://127.0.0.1:5000");
        scopePanel.add(scopeHelp, BorderLayout.NORTH);
        scopePanel.add(scopeField, BorderLayout.CENTER);

        JPanel usersPanel = new JPanel(new GridBagLayout());
        usersPanel.setBorder(BorderFactory.createTitledBorder("Users / identities"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        for (int i = 0; i < 3; i++) {
            UserEditor editor = new UserEditor(i + 1);
            userEditors.add(editor);

            gbc.gridy = i;
            usersPanel.add(editor.panel, gbc);
        }

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton save = new JButton("Save Environment");
        save.addActionListener(e -> saveEnvironment());

        JButton clearResults = new JButton("Clear Results");
        clearResults.addActionListener(e -> clearResults());

        environmentStatus = new JLabel("Configure the scope and at least one enabled identity.");

        buttons.add(save);
        buttons.add(clearResults);
        buttons.add(environmentStatus);

        JPanel center = new JPanel(new BorderLayout(10, 10));
        center.add(scopePanel, BorderLayout.NORTH);
        center.add(new JScrollPane(usersPanel), BorderLayout.CENTER);

        outer.add(center, BorderLayout.CENTER);
        outer.add(buttons, BorderLayout.SOUTH);

        return outer;
    }

    private JPanel buildResultsPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        resultsModel = new DefaultTableModel(
                new Object[]{"Run", "User", "Method", "URL", "Status", "Length", "Time (ms)"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        resultsTable = new JTable(resultsModel);
        resultsTable.setAutoCreateRowSorter(true);
        resultsTable.setFillsViewportHeight(true);
        resultsTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        JScrollPane resultsScroll = new JScrollPane(resultsTable);
        resultsScroll.setBorder(BorderFactory.createTitledBorder("Results"));

        requestViewer = api.userInterface().createHttpRequestEditor(EditorOptions.READ_ONLY);
        responseViewer = api.userInterface().createHttpResponseEditor(EditorOptions.READ_ONLY);

        JPanel requestPanel = new JPanel(new BorderLayout());
        requestPanel.setBorder(BorderFactory.createTitledBorder("Request"));
        requestPanel.add(requestViewer.uiComponent(), BorderLayout.CENTER);

        JPanel responsePanel = new JPanel(new BorderLayout());
        responsePanel.setBorder(BorderFactory.createTitledBorder("Response"));
        responsePanel.add(responseViewer.uiComponent(), BorderLayout.CENTER);

        JSplitPane messageSplit = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                requestPanel,
                responsePanel
        );
        messageSplit.setResizeWeight(0.5);
        messageSplit.setOneTouchExpandable(true);

        JSplitPane mainSplit = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                resultsScroll,
                messageSplit
        );
        mainSplit.setResizeWeight(0.38);
        mainSplit.setOneTouchExpandable(true);

        resultsTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                showSelectedResult();
            }
        });

        JLabel hint = new JLabel(
                "Select a result row to inspect the exact replayed request and response."
        );

        panel.add(hint, BorderLayout.NORTH);
        panel.add(mainSplit, BorderLayout.CENTER);

        return panel;
    }

    private void showSelectedResult() {
        int viewRow = resultsTable.getSelectedRow();

        if (viewRow < 0) {
            return;
        }

        int modelRow = resultsTable.convertRowIndexToModel(viewRow);

        if (modelRow < 0 || modelRow >= resultEntries.size()) {
            return;
        }

        ResultEntry entry = resultEntries.get(modelRow);

        requestViewer.setRequest(entry.request);

        if (entry.response != null) {
            responseViewer.setResponse(entry.response);
        } else {
            responseViewer.setResponse(HttpResponse.httpResponse());
        }
    }

    private void clearResults() {
        if (resultsModel != null) {
            resultsModel.setRowCount(0);
        }

        resultEntries.clear();

        if (resultsTable != null) {
            resultsTable.clearSelection();
        }

        if (requestViewer != null) {
            requestViewer.setRequest(HttpRequest.httpRequest());
        }

        if (responseViewer != null) {
            responseViewer.setResponse(HttpResponse.httpResponse());
        }
    }

    private void saveEnvironment() {
        try {
            Environment candidate = environmentFromUi();
            this.environment = candidate;

            preferences.setString("scope", candidate.scopePrefix);

            for (int i = 0; i < userEditors.size(); i++) {
                UserEditor editor = userEditors.get(i);
                preferences.setString("user." + i + ".name", editor.nameField.getText().trim());
                preferences.setString("user." + i + ".headers", editor.headersArea.getText());
                preferences.setBoolean("user." + i + ".enabled", editor.enabledBox.isSelected());
            }

            environmentStatus.setText(
                    "Saved. " + candidate.identities.size() + " identities enabled."
            );

            api.logging().logToOutput(
                    "Auth Repeater environment saved. Scope: " + candidate.scopePrefix
            );
        } catch (IllegalArgumentException ex) {
            environmentStatus.setText("Configuration error: " + ex.getMessage());
            JOptionPane.showMessageDialog(
                    mainPanel,
                    ex.getMessage(),
                    "Auth Repeater - invalid environment",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loadSavedEnvironment() {
        String savedScope = preferences.getString("scope");
        scopeField.setText(savedScope == null ? "" : savedScope);

        for (int i = 0; i < userEditors.size(); i++) {
            UserEditor editor = userEditors.get(i);

            String name = preferences.getString("user." + i + ".name");
            String headers = preferences.getString("user." + i + ".headers");
            Boolean enabled = preferences.getBoolean("user." + i + ".enabled");

            if (name != null && !name.isBlank()) {
                editor.nameField.setText(name);
            }

            if (headers != null) {
                editor.headersArea.setText(headers);
            }

            if (enabled != null) {
                editor.enabledBox.setSelected(enabled);
            }
        }

        // If a valid environment was stored previously, activate it immediately.
        try {
            if (savedScope != null && !savedScope.isBlank()) {
                this.environment = environmentFromUi();
                environmentStatus.setText(
                        "Loaded. " + environment.identities.size() + " identities enabled."
                );
            }
        } catch (IllegalArgumentException ignored) {
            environmentStatus.setText("Stored environment needs review.");
        }
    }

    private Environment environmentFromUi() {
        String scope = scopeField.getText().trim();

        if (scope.isBlank()) {
            throw new IllegalArgumentException("Scope cannot be empty.");
        }

        if (!scope.startsWith("http://") && !scope.startsWith("https://")) {
            throw new IllegalArgumentException(
                    "Scope must begin with http:// or https://"
            );
        }

        List<Identity> identities = new ArrayList<>();
        Set<String> managedHeaderNames = new LinkedHashSet<>();

        // Always remove common authentication headers inherited from the original request.
        managedHeaderNames.add("Cookie");
        managedHeaderNames.add("Authorization");
        managedHeaderNames.add("Proxy-Authorization");

        for (UserEditor editor : userEditors) {
            if (!editor.enabledBox.isSelected()) {
                continue;
            }

            String name = editor.nameField.getText().trim();
            if (name.isBlank()) {
                throw new IllegalArgumentException("An enabled user has no name.");
            }

            Map<String, String> headers = parseHeaders(editor.headersArea.getText(), name);

            if (headers.isEmpty()) {
                throw new IllegalArgumentException(
                        name + " is enabled but has no identity headers."
                );
            }

            managedHeaderNames.addAll(headers.keySet());
            identities.add(new Identity(name, headers));
        }

        if (identities.isEmpty()) {
            throw new IllegalArgumentException("Enable at least one user.");
        }

        return new Environment(scope, identities, managedHeaderNames);
    }

    private Map<String, String> parseHeaders(String text, String userName) {
        Map<String, String> headers = new LinkedHashMap<>();

        String[] lines = text.split("\\R");

        for (String rawLine : lines) {
            String line = rawLine.trim();

            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }

            int colon = line.indexOf(':');
            if (colon <= 0) {
                throw new IllegalArgumentException(
                        userName + ": invalid header line: " + line
                );
            }

            String headerName = line.substring(0, colon).trim();
            String headerValue = line.substring(colon + 1).trim();

            if (headerName.isEmpty()) {
                throw new IllegalArgumentException(
                        userName + ": empty header name."
                );
            }

            String lower = headerName.toLowerCase(Locale.ROOT);

            if (lower.equals("host") || lower.equals("content-length")) {
                throw new IllegalArgumentException(
                        userName + ": " + headerName + " cannot be used as an identity header."
                );
            }

            headers.put(headerName, headerValue);
        }

        return headers;
    }

    private void submitRequest(HttpRequest originalRequest) {
        Environment snapshot = this.environment;

        if (snapshot == null) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Configure and save an environment first.",
                    "Auth Repeater",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String url;
        try {
            url = originalRequest.url();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Burp could not parse the selected request URL.",
                    "Auth Repeater",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (!url.startsWith(snapshot.scopePrefix)) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Request is outside the configured scope:\n" + url +
                            "\n\nScope:\n" + snapshot.scopePrefix,
                    "Auth Repeater - outside scope",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int runId = runCounter.incrementAndGet();

        api.logging().logToOutput(
                "Auth Repeater run #" + runId + ": " + originalRequest.method() + " " + url
        );

        worker.submit(() -> executeRun(runId, originalRequest, snapshot));
    }

    private void executeRun(int runId, HttpRequest originalRequest, Environment snapshot) {
        for (Identity identity : snapshot.identities) {
            HttpRequest requestForUser = originalRequest;

            // Remove all known identity headers so credentials from the request that was
            // sent to the extension cannot leak into another user's replay.
            for (String headerName : snapshot.managedHeaderNames) {
                requestForUser = requestForUser.withRemovedHeader(headerName);
            }

            // Apply this user's configured identity.
            for (Map.Entry<String, String> header : identity.headers.entrySet()) {
                requestForUser = requestForUser.withHeader(header.getKey(), header.getValue());
            }

            long start = System.nanoTime();

            try {
                HttpRequestResponse exchange = api.http().sendRequest(requestForUser);
                long elapsedMs = (System.nanoTime() - start) / 1_000_000L;

                if (!exchange.hasResponse() || exchange.response() == null) {
                    addResult(
                            runId,
                            identity.name,
                            requestForUser.method(),
                            requestForUser.url(),
                            "NO RESPONSE",
                            0,
                            elapsedMs,
                            requestForUser,
                            null
                    );
                    continue;
                }

                HttpResponse response = exchange.response();
                String status = response.statusCode() + " " + response.reasonPhrase();
                int length = response.toByteArray().length();

                addResult(
                        runId,
                        identity.name,
                        requestForUser.method(),
                        requestForUser.url(),
                        status.trim(),
                        length,
                        elapsedMs,
                        requestForUser,
                        response
                );
            } catch (Exception ex) {
                long elapsedMs = (System.nanoTime() - start) / 1_000_000L;

                addResult(
                        runId,
                        identity.name,
                        requestForUser.method(),
                        safeUrl(requestForUser),
                        "ERROR: " + ex.getClass().getSimpleName(),
                        0,
                        elapsedMs,
                        requestForUser,
                        null
                );

                api.logging().logToError(
                        "Auth Repeater error for " + identity.name + ": " + ex.getMessage()
                );
            }
        }
    }

    private String safeUrl(HttpRequest request) {
        try {
            return request.url();
        } catch (RuntimeException ex) {
            return "<unparseable URL>";
        }
    }

    private void addResult(
            int run,
            String user,
            String method,
            String url,
            String status,
            int length,
            long elapsedMs,
            HttpRequest request,
            HttpResponse response
    ) {
        SwingUtilities.invokeLater(() -> {
            resultEntries.add(new ResultEntry(request, response));

            resultsModel.addRow(new Object[]{
                    run,
                    user,
                    method,
                    url,
                    status,
                    length,
                    elapsedMs
            });

            int modelRow = resultsModel.getRowCount() - 1;
            int viewRow = resultsTable.convertRowIndexToView(modelRow);

            if (viewRow >= 0) {
                resultsTable.setRowSelectionInterval(viewRow, viewRow);
            }
        });
    }

    private static final class ResultEntry {
        final HttpRequest request;
        final HttpResponse response;

        ResultEntry(HttpRequest request, HttpResponse response) {
            this.request = request;
            this.response = response;
        }
    }

    private static final class Environment {
        final String scopePrefix;
        final List<Identity> identities;
        final Set<String> managedHeaderNames;

        Environment(
                String scopePrefix,
                List<Identity> identities,
                Set<String> managedHeaderNames
        ) {
            this.scopePrefix = scopePrefix;
            this.identities = List.copyOf(identities);
            this.managedHeaderNames = Set.copyOf(managedHeaderNames);
        }
    }

    private static final class Identity {
        final String name;
        final Map<String, String> headers;

        Identity(String name, Map<String, String> headers) {
            this.name = name;
            this.headers = Map.copyOf(headers);
        }
    }

    private static final class UserEditor {
        final JPanel panel;
        final JCheckBox enabledBox;
        final JTextField nameField;
        final JTextArea headersArea;

        UserEditor(int number) {
            panel = new JPanel(new BorderLayout(8, 8));
            panel.setBorder(BorderFactory.createTitledBorder("User " + number));
            panel.setPreferredSize(new Dimension(700, 145));

            JPanel top = new JPanel(new BorderLayout(8, 8));

            enabledBox = new JCheckBox("Enabled", true);
            nameField = new JTextField("User " + number);

            top.add(enabledBox, BorderLayout.WEST);
            top.add(new JLabel("Name:"), BorderLayout.CENTER);
            top.add(nameField, BorderLayout.EAST);
            nameField.setPreferredSize(new Dimension(240, 26));

            headersArea = new JTextArea(4, 60);
            headersArea.setLineWrap(false);
            headersArea.setToolTipText(
                    "One header per line. Examples: Cookie: session=... or Authorization: Bearer ..."
            );

            JScrollPane headersScroll = new JScrollPane(headersArea);
            headersScroll.setBorder(BorderFactory.createTitledBorder(
                    "Identity headers - one per line (Header-Name: value)"
            ));

            panel.add(top, BorderLayout.NORTH);
            panel.add(headersScroll, BorderLayout.CENTER);
        }
    }
}
