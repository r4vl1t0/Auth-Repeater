import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.persistence.Preferences;
import burp.api.montoya.ui.editor.EditorOptions;
import burp.api.montoya.ui.editor.HttpRequestEditor;
import burp.api.montoya.ui.editor.HttpResponseEditor;
import burp.api.montoya.ui.contextmenu.ContextMenuEvent;
import burp.api.montoya.ui.contextmenu.ContextMenuItemsProvider;
import burp.api.montoya.ui.contextmenu.MessageEditorHttpRequestResponse;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Point;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Extension implements BurpExtension, ContextMenuItemsProvider {

    private static final String EXTENSION_NAME = "Auth Repeater";

    private MontoyaApi api;
    private Preferences preferences;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicInteger runCounter = new AtomicInteger(0);

    private JPanel mainPanel;
    private JTabbedPane mainTabs;
    private JTextField scopeField;
    private JLabel environmentStatus;

    private final List<UserEditor> userEditors = new ArrayList<>();

    private DefaultTableModel oauthModel;
    private JTable oauthTable;
    private JTextField oauthNameField;
    private JCheckBox oauthEnabledBox;
    private JTextField oauthAccessField;
    private JTextField oauthExpiresField;
    private JTextField oauthRefreshField;
    private JLabel oauthStatusLabel;
    private HttpRequestEditor oauthRequestViewer;
    private HttpResponseEditor oauthResponseViewer;
    private final List<OAuthProfile> oauthProfiles = new ArrayList<>();
    private final AtomicInteger oauthProfileCounter = new AtomicInteger(0);
    private boolean updatingOauthSelection = false;

    private DefaultTableModel resultsModel;
    private JTable resultsTable;
    private HttpRequestEditor requestViewer;
    private HttpResponseEditor responseViewer;
    private final List<ResultEntry> resultEntries = new ArrayList<>();

    private DefaultTableModel findingsModel;
    private JTable findingsTable;
    private JComboBox<String> findingUserSelector;
    private HttpRequestEditor findingRequestViewer;
    private HttpResponseEditor findingResponseViewer;
    private final List<FindingEntry> findingEntries = new ArrayList<>();
    private final AtomicInteger findingCounter = new AtomicInteger(0);
    private boolean updatingFindingSelection = false;

    // Snapshot used by the repeater after pressing "Save Environment".
    private volatile Environment environment;

    @Override
    public void initialize(MontoyaApi montoyaApi) {
        this.api = montoyaApi;
        this.preferences = api.persistence().preferences();

        api.extension().setName(EXTENSION_NAME);
        api.extension().registerUnloadingHandler(worker::shutdownNow);

        SwingUtilities.invokeLater(() -> {
            buildUi();
            loadSavedOAuthProfiles();
            loadSavedEnvironment();
            api.userInterface().registerSuiteTab("Auth Repeater", mainPanel);
        });

        api.userInterface().registerContextMenuItemsProvider(this);
        api.logging().logToOutput(EXTENSION_NAME + " loaded.");
    }

    @Override
    public List<Component> provideMenuItems(ContextMenuEvent event) {
        HttpRequest request = requestFrom(event);

        if (request == null) {
            return List.of();
        }

        JMenuItem item = new JMenuItem("Send to Auth Repeater");
        item.addActionListener(e -> submitRequest(request));

        JMenuItem oauthItem = new JMenuItem("Add as OAuth Refresh Profile...");
        oauthItem.addActionListener(e -> addOAuthProfileFromRequest(request));

        return List.of(item, oauthItem);
    }

    private HttpRequest requestFrom(ContextMenuEvent event) {
        List<HttpRequestResponse> selected = event.selectedRequestResponses();

        if (!selected.isEmpty()) {
            return selected.get(0).request();
        }

        return event.messageEditorRequestResponse()
                .map(MessageEditorHttpRequestResponse::requestResponse)
                .map(HttpRequestResponse::request)
                .orElse(null);
    }

    private void buildUi() {
        mainPanel = new JPanel(new BorderLayout());

        mainTabs = new JTabbedPane();
        mainTabs.addTab("Set Environment", buildEnvironmentPanel());
        mainTabs.addTab("OAuth Profiles", buildOAuthPanel());
        mainTabs.addTab("Results Log", buildResultsPanel());
        mainTabs.addTab("Findings", buildFindingsPanel());

        mainPanel.add(mainTabs, BorderLayout.CENTER);
        api.userInterface().applyThemeToComponent(mainPanel);
    }

    private JPanel buildEnvironmentPanel() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel scopePanel = new JPanel(new BorderLayout(8, 8));
        scopePanel.setBorder(BorderFactory.createTitledBorder("Scope"));

        scopeField = new JTextField();
        scopeField.setToolTipText("Example: http://127.0.0.1:5000");

        JLabel scopeHelp = new JLabel("URL prefix, for example: http://127.0.0.1:5000");
        scopePanel.add(scopeHelp, BorderLayout.NORTH);
        scopePanel.add(scopeField, BorderLayout.CENTER);

        JPanel usersPanel = new JPanel(new GridBagLayout());
        usersPanel.setBorder(BorderFactory.createTitledBorder("Users / identities"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        for (int i = 0; i < 3; i++) {
            UserEditor editor = new UserEditor(i + 1);
            userEditors.add(editor);

            gbc.gridy = i;
            usersPanel.add(editor.panel, gbc);
        }

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton save = new JButton("Save Environment");
        save.addActionListener(e -> saveEnvironment());

        JButton clearResults = new JButton("Clear Results");
        clearResults.addActionListener(e -> clearResults());

        environmentStatus = new JLabel("Configure the scope. Static identities are optional when OAuth Profiles are enabled.");

        buttons.add(save);
        buttons.add(clearResults);
        buttons.add(environmentStatus);

        JPanel center = new JPanel(new BorderLayout(10, 10));
        center.add(scopePanel, BorderLayout.NORTH);
        center.add(new JScrollPane(usersPanel), BorderLayout.CENTER);

        outer.add(center, BorderLayout.CENTER);
        outer.add(buttons, BorderLayout.SOUTH);

        return outer;
    }


    private JPanel buildOAuthPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        oauthModel = new DefaultTableModel(
                new Object[]{"Enabled", "Name", "Refresh URL", "Status", "Expires"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        oauthTable = new JTable(oauthModel);
        oauthTable.setAutoCreateRowSorter(true);
        oauthTable.setFillsViewportHeight(true);
        oauthTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        JScrollPane tableScroll = new JScrollPane(oauthTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder("OAuth refresh profiles"));

        JPanel editor = new JPanel(new GridBagLayout());
        editor.setBorder(BorderFactory.createTitledBorder("Selected profile"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 5, 4, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        oauthEnabledBox = new JCheckBox("Enabled", true);
        oauthNameField = new JTextField();
        oauthAccessField = new JTextField("access_token");
        oauthExpiresField = new JTextField("expires_in");
        oauthRefreshField = new JTextField("refresh_token");
        oauthStatusLabel = new JLabel("Select a profile.");

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        editor.add(oauthEnabledBox, gbc);
        gbc.gridx = 1; gbc.weightx = 0;
        editor.add(new JLabel("Name:"), gbc);
        gbc.gridx = 2; gbc.weightx = 1;
        editor.add(oauthNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        editor.add(new JLabel("Access token field:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2; gbc.weightx = 1;
        editor.add(oauthAccessField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1; gbc.weightx = 0;
        editor.add(new JLabel("Expiration field:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2; gbc.weightx = 1;
        editor.add(oauthExpiresField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 1; gbc.weightx = 0;
        editor.add(new JLabel("Refresh token field:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2; gbc.weightx = 1;
        editor.add(oauthRefreshField, gbc);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton saveProfile = new JButton("Save Profile");
        saveProfile.addActionListener(event -> saveSelectedOAuthProfile());

        JButton refreshNow = new JButton("Refresh Now");
        refreshNow.addActionListener(event -> refreshSelectedOAuthProfile());

        JButton removeProfile = new JButton("Remove Profile");
        removeProfile.addActionListener(event -> removeSelectedOAuthProfile());

        controls.add(saveProfile);
        controls.add(refreshNow);
        controls.add(removeProfile);
        controls.add(oauthStatusLabel);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 3; gbc.weightx = 1;
        editor.add(controls, gbc);

        oauthRequestViewer = api.userInterface().createHttpRequestEditor(EditorOptions.READ_ONLY);
        oauthResponseViewer = api.userInterface().createHttpResponseEditor(EditorOptions.READ_ONLY);

        JPanel requestPanel = new JPanel(new BorderLayout());
        requestPanel.setBorder(BorderFactory.createTitledBorder("Refresh request"));
        requestPanel.add(oauthRequestViewer.uiComponent(), BorderLayout.CENTER);

        JPanel responsePanel = new JPanel(new BorderLayout());
        responsePanel.setBorder(BorderFactory.createTitledBorder("Last refresh response"));
        responsePanel.add(oauthResponseViewer.uiComponent(), BorderLayout.CENTER);

        JSplitPane messageSplit = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                requestPanel,
                responsePanel
        );
        messageSplit.setResizeWeight(0.5);
        messageSplit.setOneTouchExpandable(true);

        JPanel lower = new JPanel(new BorderLayout(8, 8));
        lower.add(editor, BorderLayout.NORTH);
        lower.add(messageSplit, BorderLayout.CENTER);

        JSplitPane mainSplit = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                tableScroll,
                lower
        );
        mainSplit.setResizeWeight(0.30);
        mainSplit.setOneTouchExpandable(true);

        oauthTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                showSelectedOAuthProfile();
            }
        });

        JLabel hint = new JLabel(
                "Capture a real OAuth refresh-token request, then right-click it > Add as OAuth Refresh Profile..."
        );

        panel.add(hint, BorderLayout.NORTH);
        panel.add(mainSplit, BorderLayout.CENTER);

        return panel;
    }

    private void addOAuthProfileFromRequest(HttpRequest request) {
        SwingUtilities.invokeLater(() -> {
            String suggestedName = "OAuth User " + (oauthProfileCounter.get() + 1);
            String name = JOptionPane.showInputDialog(
                    mainPanel,
                    "Profile name (for example: Master OAuth):",
                    suggestedName
            );

            if (name == null) {
                return;
            }

            name = name.trim();
            if (name.isBlank()) {
                JOptionPane.showMessageDialog(
                        mainPanel,
                        "Profile name cannot be empty.",
                        "Auth Repeater",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            OAuthProfile profile = new OAuthProfile(
                    oauthProfileCounter.incrementAndGet(),
                    name,
                    true,
                    "access_token",
                    "expires_in",
                    "refresh_token",
                    request.copyToTempFile()
            );

            profile.currentRefreshToken = extractRefreshTokenFromRequest(
                    profile.refreshRequest,
                    profile.refreshTokenField
            );
            profile.status = "Captured - token not refreshed yet";

            oauthProfiles.add(profile);
            oauthModel.addRow(oauthRow(profile));
            saveOAuthProfilesToPreferences();

            int modelRow = oauthProfiles.size() - 1;
            int viewRow = oauthTable.convertRowIndexToView(modelRow);
            if (viewRow >= 0) {
                oauthTable.setRowSelectionInterval(viewRow, viewRow);
            }

            mainTabs.setSelectedIndex(1);
            worker.submit(() -> {
                try {
                    refreshOAuthProfile(profile);
                } catch (Exception ex) {
                    setOAuthError(profile, ex.getMessage());
                }
            });
        });
    }

    private Object[] oauthRow(OAuthProfile profile) {
        return new Object[]{
                profile.enabled ? "Yes" : "No",
                profile.name,
                safeUrl(profile.refreshRequest),
                profile.status,
                oauthExpiryText(profile)
        };
    }

    private void showSelectedOAuthProfile() {
        int viewRow = oauthTable.getSelectedRow();
        if (viewRow < 0) {
            return;
        }

        int modelRow = oauthTable.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= oauthProfiles.size()) {
            return;
        }

        OAuthProfile profile = oauthProfiles.get(modelRow);

        updatingOauthSelection = true;
        oauthEnabledBox.setSelected(profile.enabled);
        oauthNameField.setText(profile.name);
        oauthAccessField.setText(profile.accessTokenField);
        oauthExpiresField.setText(profile.expiresField);
        oauthRefreshField.setText(profile.refreshTokenField);
        oauthStatusLabel.setText(profile.status + " | Expires: " + oauthExpiryText(profile));
        updatingOauthSelection = false;

        oauthRequestViewer.setRequest(profile.refreshRequest);
        if (profile.lastResponse != null) {
            oauthResponseViewer.setResponse(profile.lastResponse);
        } else {
            oauthResponseViewer.setResponse(HttpResponse.httpResponse());
        }
    }

    private void saveSelectedOAuthProfile() {
        if (updatingOauthSelection) {
            return;
        }

        int viewRow = oauthTable.getSelectedRow();
        if (viewRow < 0) {
            return;
        }

        int modelRow = oauthTable.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= oauthProfiles.size()) {
            return;
        }

        OAuthProfile profile = oauthProfiles.get(modelRow);
        String name = oauthNameField.getText().trim();
        String accessField = oauthAccessField.getText().trim();
        String expiresField = oauthExpiresField.getText().trim();
        String refreshField = oauthRefreshField.getText().trim();

        if (name.isBlank() || accessField.isBlank() || refreshField.isBlank()) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Name, access token field and refresh token field cannot be empty.",
                    "Auth Repeater",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        profile.name = name;
        profile.enabled = oauthEnabledBox.isSelected();
        profile.accessTokenField = accessField;
        profile.expiresField = expiresField;
        profile.refreshTokenField = refreshField;
        profile.currentRefreshToken = extractRefreshTokenFromRequest(
                profile.refreshRequest,
                profile.refreshTokenField
        );
        profile.currentAccessToken = null;
        profile.expiresAtEpochMs = 0L;
        profile.status = "Saved - refresh required";

        refreshOAuthTableRow(profile);
        saveOAuthProfilesToPreferences();
        showSelectedOAuthProfile();
    }

    private void refreshSelectedOAuthProfile() {
        int viewRow = oauthTable.getSelectedRow();
        if (viewRow < 0) {
            return;
        }

        int modelRow = oauthTable.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= oauthProfiles.size()) {
            return;
        }

        OAuthProfile profile = oauthProfiles.get(modelRow);
        profile.status = "Refreshing...";
        refreshOAuthTableRow(profile);

        worker.submit(() -> {
            try {
                refreshOAuthProfile(profile);
            } catch (Exception ex) {
                setOAuthError(profile, ex.getMessage());
            }
        });
    }

    private void removeSelectedOAuthProfile() {
        int viewRow = oauthTable.getSelectedRow();
        if (viewRow < 0) {
            return;
        }

        int modelRow = oauthTable.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= oauthProfiles.size()) {
            return;
        }

        oauthProfiles.remove(modelRow);
        oauthModel.removeRow(modelRow);
        saveOAuthProfilesToPreferences();

        oauthNameField.setText("");
        oauthAccessField.setText("access_token");
        oauthExpiresField.setText("expires_in");
        oauthRefreshField.setText("refresh_token");
        oauthStatusLabel.setText("Select a profile.");
        oauthRequestViewer.setRequest(HttpRequest.httpRequest());
        oauthResponseViewer.setResponse(HttpResponse.httpResponse());
    }

    private void refreshOAuthTableRow(OAuthProfile profile) {
        SwingUtilities.invokeLater(() -> {
            int modelRow = oauthProfiles.indexOf(profile);
            if (modelRow < 0 || modelRow >= oauthModel.getRowCount()) {
                return;
            }

            Object[] row = oauthRow(profile);
            for (int col = 0; col < row.length; col++) {
                oauthModel.setValueAt(row[col], modelRow, col);
            }

            int selectedViewRow = oauthTable.getSelectedRow();
            if (selectedViewRow >= 0 && oauthTable.convertRowIndexToModel(selectedViewRow) == modelRow) {
                oauthStatusLabel.setText(profile.status + " | Expires: " + oauthExpiryText(profile));
                oauthRequestViewer.setRequest(profile.refreshRequest);
                if (profile.lastResponse != null) {
                    oauthResponseViewer.setResponse(profile.lastResponse);
                }
            }
        });
    }

    private String oauthExpiryText(OAuthProfile profile) {
        if (profile.currentAccessToken == null || profile.currentAccessToken.isBlank()) {
            return "No token";
        }

        if (profile.expiresAtEpochMs <= 0) {
            return "Unknown";
        }

        long remainingMs = profile.expiresAtEpochMs - System.currentTimeMillis();
        if (remainingMs <= 0) {
            return "Expired";
        }

        long seconds = remainingMs / 1000L;
        if (seconds < 60) {
            return seconds + "s";
        }

        long minutes = seconds / 60L;
        long rest = seconds % 60L;
        return minutes + "m " + rest + "s";
    }

    private List<OAuthProfile> enabledOAuthProfilesSnapshot() {
        List<OAuthProfile> enabled = new ArrayList<>();
        for (OAuthProfile profile : oauthProfiles) {
            if (profile.enabled) {
                enabled.add(profile);
            }
        }
        return enabled;
    }

    private void loadSavedOAuthProfiles() {
        String countText = preferences.getString("oauth.count");
        int count = 0;

        try {
            if (countText != null) {
                count = Integer.parseInt(countText);
            }
        } catch (NumberFormatException ignored) {
            count = 0;
        }

        for (int i = 0; i < count; i++) {
            String prefix = "oauth." + i + ".";
            String name = preferences.getString(prefix + "name");
            String accessField = preferences.getString(prefix + "accessField");
            String expiresField = preferences.getString(prefix + "expiresField");
            String refreshField = preferences.getString(prefix + "refreshField");
            String host = preferences.getString(prefix + "host");
            String portText = preferences.getString(prefix + "port");
            String secureText = preferences.getString(prefix + "secure");
            String rawRequest = preferences.getString(prefix + "request");
            Boolean enabled = preferences.getBoolean(prefix + "enabled");

            if (name == null || host == null || portText == null || rawRequest == null) {
                continue;
            }

            try {
                int port = Integer.parseInt(portText);
                boolean secure = Boolean.parseBoolean(secureText);
                HttpService service = HttpService.httpService(host, port, secure);
                HttpRequest refreshRequest = HttpRequest.httpRequest(service, rawRequest).copyToTempFile();

                OAuthProfile profile = new OAuthProfile(
                        oauthProfileCounter.incrementAndGet(),
                        name,
                        enabled == null || enabled,
                        accessField == null || accessField.isBlank() ? "access_token" : accessField,
                        expiresField == null ? "expires_in" : expiresField,
                        refreshField == null || refreshField.isBlank() ? "refresh_token" : refreshField,
                        refreshRequest
                );

                profile.currentRefreshToken = extractRefreshTokenFromRequest(
                        refreshRequest,
                        profile.refreshTokenField
                );
                profile.status = "Loaded - refresh on first use";

                oauthProfiles.add(profile);
                oauthModel.addRow(oauthRow(profile));
            } catch (Exception ex) {
                api.logging().logToError("Could not load OAuth profile " + name + ": " + ex.getMessage());
            }
        }
    }

    private void saveOAuthProfilesToPreferences() {
        preferences.setString("oauth.count", String.valueOf(oauthProfiles.size()));

        for (int i = 0; i < oauthProfiles.size(); i++) {
            OAuthProfile profile = oauthProfiles.get(i);
            String prefix = "oauth." + i + ".";
            HttpService service = profile.refreshRequest.httpService();

            preferences.setString(prefix + "name", profile.name);
            preferences.setBoolean(prefix + "enabled", profile.enabled);
            preferences.setString(prefix + "accessField", profile.accessTokenField);
            preferences.setString(prefix + "expiresField", profile.expiresField);
            preferences.setString(prefix + "refreshField", profile.refreshTokenField);
            preferences.setString(prefix + "host", service.host());
            preferences.setString(prefix + "port", String.valueOf(service.port()));
            preferences.setString(prefix + "secure", String.valueOf(service.secure()));
            preferences.setString(prefix + "request", profile.refreshRequest.toString());
        }
    }

    private String validAccessToken(OAuthProfile profile) throws Exception {
        synchronized (profile) {
            long now = System.currentTimeMillis();
            boolean knownAndValid = profile.currentAccessToken != null
                    && !profile.currentAccessToken.isBlank()
                    && profile.expiresAtEpochMs > 0
                    && now < (profile.expiresAtEpochMs - 30_000L);

            if (knownAndValid) {
                return profile.currentAccessToken;
            }

            // If expiry is unknown, refresh on every replay rather than risk using a stale token.
            refreshOAuthProfile(profile);

            if (profile.currentAccessToken == null || profile.currentAccessToken.isBlank()) {
                throw new IllegalStateException("Refresh response did not produce an access token.");
            }

            return profile.currentAccessToken;
        }
    }

    private void refreshOAuthProfile(OAuthProfile profile) throws Exception {
        synchronized (profile) {
            HttpRequest refreshRequest = profile.refreshRequest;
            HttpRequestResponse exchange = api.http().sendRequest(refreshRequest);

            if (!exchange.hasResponse() || exchange.response() == null) {
                throw new IllegalStateException("OAuth refresh endpoint returned no response.");
            }

            HttpResponse response = exchange.response();
            profile.lastResponse = response.copyToTempFile();

            int statusCode = response.statusCode();
            if (statusCode < 200 || statusCode >= 300) {
                throw new IllegalStateException(
                        "Refresh failed with HTTP " + statusCode + " " + response.reasonPhrase()
                );
            }

            String body = response.bodyToString();
            String accessToken = extractJsonString(body, profile.accessTokenField);

            if (accessToken == null || accessToken.isBlank()) {
                throw new IllegalStateException(
                        "Field '" + profile.accessTokenField + "' was not found in refresh response."
                );
            }

            long expiresAt = 0L;
            Long expiresIn = extractJsonLong(body, profile.expiresField);

            if (expiresIn != null && expiresIn > 0) {
                expiresAt = System.currentTimeMillis() + (expiresIn * 1000L);
            } else {
                Long jwtExp = parseJwtExp(accessToken);
                if (jwtExp != null && jwtExp > 0) {
                    expiresAt = jwtExp * 1000L;
                }
            }

            String rotatedRefreshToken = extractJsonString(body, profile.refreshTokenField);
            if (rotatedRefreshToken != null && !rotatedRefreshToken.isBlank()) {
                String previous = profile.currentRefreshToken;
                profile.refreshRequest = replaceRefreshTokenInRequest(
                        profile.refreshRequest,
                        profile.refreshTokenField,
                        previous,
                        rotatedRefreshToken
                ).copyToTempFile();
                profile.currentRefreshToken = rotatedRefreshToken;
            }

            profile.currentAccessToken = accessToken;
            profile.expiresAtEpochMs = expiresAt;
            profile.status = "Token valid";

            saveOAuthProfilesToPreferences();
            refreshOAuthTableRow(profile);

            api.logging().logToOutput(
                    "OAuth profile '" + profile.name + "' refreshed successfully."
            );
        }
    }

    private void setOAuthError(OAuthProfile profile, String message) {
        profile.status = "Error: " + (message == null ? "unknown error" : message);
        refreshOAuthTableRow(profile);
        api.logging().logToError("OAuth profile '" + profile.name + "': " + profile.status);
    }

    private String extractRefreshTokenFromRequest(HttpRequest request, String fieldName) {
        String body = request.bodyToString();

        String formValue = extractFormField(body, fieldName);
        if (formValue != null) {
            return formValue;
        }

        return extractJsonString(body, fieldName);
    }

    private String extractFormField(String body, String fieldName) {
        if (body == null || body.isBlank()) {
            return null;
        }

        String[] parts = body.split("&");
        for (String part : parts) {
            int equals = part.indexOf('=');
            String rawName = equals >= 0 ? part.substring(0, equals) : part;
            String rawValue = equals >= 0 ? part.substring(equals + 1) : "";

            String decodedName = URLDecoder.decode(rawName, StandardCharsets.UTF_8);
            if (decodedName.equals(fieldName)) {
                return URLDecoder.decode(rawValue, StandardCharsets.UTF_8);
            }
        }

        return null;
    }

    private HttpRequest replaceRefreshTokenInRequest(
            HttpRequest request,
            String fieldName,
            String oldToken,
            String newToken
    ) {
        String body = request.bodyToString();
        String replaced = replaceFormField(body, fieldName, newToken);

        if (replaced.equals(body)) {
            replaced = replaceJsonStringField(body, fieldName, newToken);
        }

        if (!replaced.equals(body)) {
            return request.withBody(replaced);
        }

        if (oldToken != null && !oldToken.isBlank()) {
            String raw = request.toString();
            String changed = raw.replace(oldToken, newToken);

            String encodedOld = URLEncoder.encode(oldToken, StandardCharsets.UTF_8);
            String encodedNew = URLEncoder.encode(newToken, StandardCharsets.UTF_8);
            changed = changed.replace(encodedOld, encodedNew);

            if (!changed.equals(raw)) {
                return HttpRequest.httpRequest(request.httpService(), changed);
            }
        }

        return request;
    }

    private String replaceFormField(String body, String fieldName, String value) {
        if (body == null || body.isBlank()) {
            return body == null ? "" : body;
        }

        String[] parts = body.split("&", -1);
        boolean changed = false;

        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            int equals = part.indexOf('=');
            String rawName = equals >= 0 ? part.substring(0, equals) : part;
            String decodedName = URLDecoder.decode(rawName, StandardCharsets.UTF_8);

            if (decodedName.equals(fieldName)) {
                parts[i] = rawName + "=" + URLEncoder.encode(value, StandardCharsets.UTF_8);
                changed = true;
            }
        }

        return changed ? String.join("&", parts) : body;
    }

    private String replaceJsonStringField(String json, String fieldName, String value) {
        if (json == null || json.isBlank()) {
            return json == null ? "" : json;
        }

        Pattern pattern = Pattern.compile(
                "(\\\"" + Pattern.quote(fieldName) + "\\\"\\s*:\\s*\\\")((?:\\\\.|[^\\\"\\\\])*)(\\\")"
        );
        Matcher matcher = pattern.matcher(json);

        if (!matcher.find()) {
            return json;
        }

        String escaped = jsonEscape(value);
        return matcher.replaceFirst(
                Matcher.quoteReplacement(matcher.group(1) + escaped + matcher.group(3))
        );
    }

    private String extractJsonString(String json, String fieldName) {
        if (json == null || json.isBlank() || fieldName == null || fieldName.isBlank()) {
            return null;
        }

        Pattern pattern = Pattern.compile(
                "\\\"" + Pattern.quote(fieldName) + "\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"\\\\])*)\\\""
        );
        Matcher matcher = pattern.matcher(json);

        return matcher.find() ? jsonUnescape(matcher.group(1)) : null;
    }

    private Long extractJsonLong(String json, String fieldName) {
        if (json == null || json.isBlank() || fieldName == null || fieldName.isBlank()) {
            return null;
        }

        Pattern pattern = Pattern.compile(
                "\\\"" + Pattern.quote(fieldName) + "\\\"\\s*:\\s*(?:\\\")?(\\d+)(?:\\\")?"
        );
        Matcher matcher = pattern.matcher(json);

        if (!matcher.find()) {
            return null;
        }

        try {
            return Long.parseLong(matcher.group(1));
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Long parseJwtExp(String token) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length < 2) {
                return null;
            }

            byte[] decoded = Base64.getUrlDecoder().decode(parts[1]);
            String payload = new String(decoded, StandardCharsets.UTF_8);
            return extractJsonLong(payload, "exp");
        } catch (Exception ignored) {
            return null;
        }
    }

    private String jsonEscape(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\t", "\\t");
    }

    private String jsonUnescape(String value) {
        StringBuilder out = new StringBuilder();
        boolean escape = false;

        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);

            if (!escape) {
                if (ch == '\\') {
                    escape = true;
                } else {
                    out.append(ch);
                }
                continue;
            }

            switch (ch) {
                case 'n' -> out.append('\n');
                case 'r' -> out.append('\r');
                case 't' -> out.append('\t');
                case 'b' -> out.append('\b');
                case 'f' -> out.append('\f');
                case '\\' -> out.append('\\');
                case '/' -> out.append('/');
                case '"' -> out.append('"');
                default -> out.append(ch);
            }
            escape = false;
        }

        if (escape) {
            out.append('\\');
        }

        return out.toString();
    }

    private JPanel buildResultsPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        resultsModel = new DefaultTableModel(
                new Object[]{"Run", "User", "Method", "URL", "Status", "Length", "Time (ms)"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        resultsTable = new JTable(resultsModel);
        resultsTable.setAutoCreateRowSorter(true);
        resultsTable.setFillsViewportHeight(true);
        resultsTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        JScrollPane resultsScroll = new JScrollPane(resultsTable);
        resultsScroll.setBorder(BorderFactory.createTitledBorder("Results"));

        requestViewer = api.userInterface().createHttpRequestEditor(EditorOptions.READ_ONLY);
        responseViewer = api.userInterface().createHttpResponseEditor(EditorOptions.READ_ONLY);

        JPanel requestPanel = new JPanel(new BorderLayout());
        requestPanel.setBorder(BorderFactory.createTitledBorder("Request"));
        requestPanel.add(requestViewer.uiComponent(), BorderLayout.CENTER);

        JPanel responsePanel = new JPanel(new BorderLayout());
        responsePanel.setBorder(BorderFactory.createTitledBorder("Response"));
        responsePanel.add(responseViewer.uiComponent(), BorderLayout.CENTER);

        JSplitPane messageSplit = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                requestPanel,
                responsePanel
        );
        messageSplit.setResizeWeight(0.5);
        messageSplit.setOneTouchExpandable(true);

        JSplitPane mainSplit = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                resultsScroll,
                messageSplit
        );
        mainSplit.setResizeWeight(0.38);
        mainSplit.setOneTouchExpandable(true);

        resultsTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent event) {
                maybeShowResultsPopup(event);
            }

            @Override
            public void mouseReleased(MouseEvent event) {
                maybeShowResultsPopup(event);
            }
        });

        resultsTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                showSelectedResult();
            }
        });

        JLabel hint = new JLabel(
                "Select a result row to inspect the exact replayed request and response."
        );

        panel.add(hint, BorderLayout.NORTH);
        panel.add(mainSplit, BorderLayout.CENTER);

        return panel;
    }

    private JPanel buildFindingsPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        findingsModel = new DefaultTableModel(
                new Object[]{"ID", "Run", "Method", "URL", "Users", "Evidence"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        findingsTable = new JTable(findingsModel);
        findingsTable.setAutoCreateRowSorter(true);
        findingsTable.setFillsViewportHeight(true);
        findingsTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        JScrollPane findingsScroll = new JScrollPane(findingsTable);
        findingsScroll.setBorder(BorderFactory.createTitledBorder("Vulnerable Endpoints"));

        findingRequestViewer = api.userInterface().createHttpRequestEditor(EditorOptions.READ_ONLY);
        findingResponseViewer = api.userInterface().createHttpResponseEditor(EditorOptions.READ_ONLY);

        JPanel requestPanel = new JPanel(new BorderLayout());
        requestPanel.setBorder(BorderFactory.createTitledBorder("Request"));
        requestPanel.add(findingRequestViewer.uiComponent(), BorderLayout.CENTER);

        JPanel responsePanel = new JPanel(new BorderLayout());
        responsePanel.setBorder(BorderFactory.createTitledBorder("Response"));
        responsePanel.add(findingResponseViewer.uiComponent(), BorderLayout.CENTER);

        JSplitPane evidenceSplit = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                requestPanel,
                responsePanel
        );
        evidenceSplit.setResizeWeight(0.5);
        evidenceSplit.setOneTouchExpandable(true);

        findingUserSelector = new JComboBox<>();
        findingUserSelector.setPreferredSize(new Dimension(220, 26));
        findingUserSelector.addActionListener(event -> {
            if (!updatingFindingSelection) {
                showSelectedFindingEvidence();
            }
        });

        JButton removeFinding = new JButton("Remove Finding");
        removeFinding.addActionListener(event -> removeSelectedFinding());

        JButton clearFindings = new JButton("Clear Findings");
        clearFindings.addActionListener(event -> clearFindings());

        JPanel evidenceControls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        evidenceControls.add(new JLabel("Evidence user:"));
        evidenceControls.add(findingUserSelector);
        evidenceControls.add(removeFinding);
        evidenceControls.add(clearFindings);

        JPanel evidencePanel = new JPanel(new BorderLayout(6, 6));
        evidencePanel.add(evidenceControls, BorderLayout.NORTH);
        evidencePanel.add(evidenceSplit, BorderLayout.CENTER);

        JSplitPane mainSplit = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                findingsScroll,
                evidencePanel
        );
        mainSplit.setResizeWeight(0.35);
        mainSplit.setOneTouchExpandable(true);

        findingsTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                showSelectedFinding();
            }
        });

        JLabel hint = new JLabel(
                "Findings are added manually from Results Log using right-click > Mark as Vulnerable."
        );

        panel.add(hint, BorderLayout.NORTH);
        panel.add(mainSplit, BorderLayout.CENTER);

        return panel;
    }

    private void maybeShowResultsPopup(MouseEvent event) {
        if (!event.isPopupTrigger()) {
            return;
        }

        Point point = event.getPoint();
        int viewRow = resultsTable.rowAtPoint(point);

        if (viewRow < 0) {
            return;
        }

        resultsTable.setRowSelectionInterval(viewRow, viewRow);
        int modelRow = resultsTable.convertRowIndexToModel(viewRow);

        if (modelRow < 0 || modelRow >= resultEntries.size()) {
            return;
        }

        ResultEntry selected = resultEntries.get(modelRow);

        JPopupMenu menu = new JPopupMenu();

        JMenuItem mark = new JMenuItem("Mark as Vulnerable");
        mark.addActionListener(action -> markRunAsVulnerable(selected.run));
        menu.add(mark);

        JMenuItem copyUrl = new JMenuItem("Copy URL");
        copyUrl.addActionListener(action -> {
            java.awt.Toolkit.getDefaultToolkit()
                    .getSystemClipboard()
                    .setContents(new java.awt.datatransfer.StringSelection(selected.url), null);
        });
        menu.add(copyUrl);

        menu.show(resultsTable, event.getX(), event.getY());
    }

    private void markRunAsVulnerable(int runId) {
        List<ResultEntry> runEntries = new ArrayList<>();

        for (ResultEntry entry : resultEntries) {
            if (entry.run == runId) {
                runEntries.add(entry);
            }
        }

        if (runEntries.isEmpty()) {
            return;
        }

        for (int i = 0; i < findingEntries.size(); i++) {
            if (findingEntries.get(i).run == runId) {
                int viewRow = findingsTable.convertRowIndexToView(i);
                if (viewRow >= 0) {
                    findingsTable.setRowSelectionInterval(viewRow, viewRow);
                }
                mainTabs.setSelectedIndex(3);
                return;
            }
        }

        ResultEntry base = runEntries.get(0);
        int findingId = findingCounter.incrementAndGet();

        StringBuilder evidence = new StringBuilder();
        for (int i = 0; i < runEntries.size(); i++) {
            ResultEntry entry = runEntries.get(i);
            if (i > 0) {
                evidence.append(" | ");
            }
            evidence.append(entry.user)
                    .append(": ")
                    .append(entry.status)
                    .append(" (")
                    .append(entry.length)
                    .append(" B)");
        }

        FindingEntry finding = new FindingEntry(
                findingId,
                runId,
                base.method,
                base.url,
                List.copyOf(runEntries)
        );

        findingEntries.add(finding);
        findingsModel.addRow(new Object[]{
                findingId,
                runId,
                base.method,
                base.url,
                runEntries.size(),
                evidence.toString()
        });

        int modelRow = findingsModel.getRowCount() - 1;
        int viewRow = findingsTable.convertRowIndexToView(modelRow);
        if (viewRow >= 0) {
            findingsTable.setRowSelectionInterval(viewRow, viewRow);
        }

        mainTabs.setSelectedIndex(3);
        api.logging().logToOutput(
                "Auth Repeater finding #" + findingId + " created from run #" + runId + ": " + base.method + " " + base.url
        );
    }

    private void showSelectedFinding() {
        int viewRow = findingsTable.getSelectedRow();

        if (viewRow < 0) {
            return;
        }

        int modelRow = findingsTable.convertRowIndexToModel(viewRow);

        if (modelRow < 0 || modelRow >= findingEntries.size()) {
            return;
        }

        FindingEntry finding = findingEntries.get(modelRow);

        updatingFindingSelection = true;
        findingUserSelector.removeAllItems();

        for (ResultEntry entry : finding.entries) {
            findingUserSelector.addItem(entry.user);
        }

        if (findingUserSelector.getItemCount() > 0) {
            findingUserSelector.setSelectedIndex(0);
        }
        updatingFindingSelection = false;

        showSelectedFindingEvidence();
    }

    private void showSelectedFindingEvidence() {
        int findingViewRow = findingsTable.getSelectedRow();
        int userIndex = findingUserSelector.getSelectedIndex();

        if (findingViewRow < 0 || userIndex < 0) {
            return;
        }

        int modelRow = findingsTable.convertRowIndexToModel(findingViewRow);

        if (modelRow < 0 || modelRow >= findingEntries.size()) {
            return;
        }

        FindingEntry finding = findingEntries.get(modelRow);

        if (userIndex >= finding.entries.size()) {
            return;
        }

        ResultEntry entry = finding.entries.get(userIndex);
        findingRequestViewer.setRequest(entry.request);

        if (entry.response != null) {
            findingResponseViewer.setResponse(entry.response);
        } else {
            findingResponseViewer.setResponse(HttpResponse.httpResponse());
        }
    }

    private void removeSelectedFinding() {
        int viewRow = findingsTable.getSelectedRow();
        if (viewRow < 0) {
            return;
        }

        int modelRow = findingsTable.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= findingEntries.size()) {
            return;
        }

        findingEntries.remove(modelRow);
        findingsModel.removeRow(modelRow);

        findingUserSelector.removeAllItems();
        findingRequestViewer.setRequest(HttpRequest.httpRequest());
        findingResponseViewer.setResponse(HttpResponse.httpResponse());
    }

    private void clearFindings() {
        findingEntries.clear();
        findingsModel.setRowCount(0);
        findingUserSelector.removeAllItems();
        findingRequestViewer.setRequest(HttpRequest.httpRequest());
        findingResponseViewer.setResponse(HttpResponse.httpResponse());
    }

    private void showSelectedResult() {
        int viewRow = resultsTable.getSelectedRow();

        if (viewRow < 0) {
            return;
        }

        int modelRow = resultsTable.convertRowIndexToModel(viewRow);

        if (modelRow < 0 || modelRow >= resultEntries.size()) {
            return;
        }

        ResultEntry entry = resultEntries.get(modelRow);

        requestViewer.setRequest(entry.request);

        if (entry.response != null) {
            responseViewer.setResponse(entry.response);
        } else {
            responseViewer.setResponse(HttpResponse.httpResponse());
        }
    }

    private void clearResults() {
        if (resultsModel != null) {
            resultsModel.setRowCount(0);
        }

        resultEntries.clear();

        if (resultsTable != null) {
            resultsTable.clearSelection();
        }

        if (requestViewer != null) {
            requestViewer.setRequest(HttpRequest.httpRequest());
        }

        if (responseViewer != null) {
            responseViewer.setResponse(HttpResponse.httpResponse());
        }
    }

    private void saveEnvironment() {
        try {
            Environment candidate = environmentFromUi();
            this.environment = candidate;

            preferences.setString("scope", candidate.scopePrefix);

            for (int i = 0; i < userEditors.size(); i++) {
                UserEditor editor = userEditors.get(i);
                preferences.setString("user." + i + ".name", editor.nameField.getText().trim());
                preferences.setString("user." + i + ".headers", editor.headersArea.getText());
                preferences.setBoolean("user." + i + ".enabled", editor.enabledBox.isSelected());
            }

            environmentStatus.setText(
                    "Saved. " + candidate.identities.size() + " static identities, "
                            + enabledOAuthProfilesSnapshot().size() + " OAuth profiles enabled."
            );

            api.logging().logToOutput(
                    "Auth Repeater environment saved. Scope: " + candidate.scopePrefix
            );
        } catch (IllegalArgumentException ex) {
            environmentStatus.setText("Configuration error: " + ex.getMessage());
            JOptionPane.showMessageDialog(
                    mainPanel,
                    ex.getMessage(),
                    "Auth Repeater - invalid environment",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loadSavedEnvironment() {
        String savedScope = preferences.getString("scope");
        scopeField.setText(savedScope == null ? "" : savedScope);

        for (int i = 0; i < userEditors.size(); i++) {
            UserEditor editor = userEditors.get(i);

            String name = preferences.getString("user." + i + ".name");
            String headers = preferences.getString("user." + i + ".headers");
            Boolean enabled = preferences.getBoolean("user." + i + ".enabled");

            if (name != null && !name.isBlank()) {
                editor.nameField.setText(name);
            }

            if (headers != null) {
                editor.headersArea.setText(headers);
            }

            if (enabled != null) {
                editor.enabledBox.setSelected(enabled);
            }
        }

        // If a valid environment was stored previously, activate it immediately.
        try {
            if (savedScope != null && !savedScope.isBlank()) {
                this.environment = environmentFromUi();
                environmentStatus.setText(
                        "Loaded. " + environment.identities.size() + " static identities, "
                                + enabledOAuthProfilesSnapshot().size() + " OAuth profiles enabled."
                );
            }
        } catch (IllegalArgumentException ignored) {
            environmentStatus.setText("Stored environment needs review.");
        }
    }

    private Environment environmentFromUi() {
        String scope = scopeField.getText().trim();

        if (scope.isBlank()) {
            throw new IllegalArgumentException("Scope cannot be empty.");
        }

        if (!scope.startsWith("http://") && !scope.startsWith("https://")) {
            throw new IllegalArgumentException(
                    "Scope must begin with http:// or https://"
            );
        }

        List<Identity> identities = new ArrayList<>();
        Set<String> managedHeaderNames = new LinkedHashSet<>();

        // Always remove common authentication headers inherited from the original request.
        managedHeaderNames.add("Cookie");
        managedHeaderNames.add("Authorization");
        managedHeaderNames.add("Proxy-Authorization");

        for (UserEditor editor : userEditors) {
            if (!editor.enabledBox.isSelected()) {
                continue;
            }

            String name = editor.nameField.getText().trim();
            if (name.isBlank()) {
                throw new IllegalArgumentException("An enabled user has no name.");
            }

            Map<String, String> headers = parseHeaders(editor.headersArea.getText(), name);

            if (headers.isEmpty()) {
                throw new IllegalArgumentException(
                        name + " is enabled but has no identity headers."
                );
            }

            managedHeaderNames.addAll(headers.keySet());
            identities.add(new Identity(name, headers));
        }

        return new Environment(scope, identities, managedHeaderNames);
    }

    private Map<String, String> parseHeaders(String text, String userName) {
        Map<String, String> headers = new LinkedHashMap<>();

        String[] lines = text.split("\\R");

        for (String rawLine : lines) {
            String line = rawLine.trim();

            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }

            int colon = line.indexOf(':');
            if (colon <= 0) {
                throw new IllegalArgumentException(
                        userName + ": invalid header line: " + line
                );
            }

            String headerName = line.substring(0, colon).trim();
            String headerValue = line.substring(colon + 1).trim();

            if (headerName.isEmpty()) {
                throw new IllegalArgumentException(
                        userName + ": empty header name."
                );
            }

            String lower = headerName.toLowerCase(Locale.ROOT);

            if (lower.equals("host") || lower.equals("content-length")) {
                throw new IllegalArgumentException(
                        userName + ": " + headerName + " cannot be used as an identity header."
                );
            }

            headers.put(headerName, headerValue);
        }

        return headers;
    }

    private void submitRequest(HttpRequest originalRequest) {
        Environment snapshot = this.environment;

        if (snapshot == null) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Configure and save an environment first.",
                    "Auth Repeater",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String url;
        try {
            url = originalRequest.url();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Burp could not parse the selected request URL.",
                    "Auth Repeater",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (!url.startsWith(snapshot.scopePrefix)) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Request is outside the configured scope:\n" + url +
                            "\n\nScope:\n" + snapshot.scopePrefix,
                    "Auth Repeater - outside scope",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        List<OAuthProfile> oauthSnapshot = enabledOAuthProfilesSnapshot();

        if (snapshot.identities.isEmpty() && oauthSnapshot.isEmpty()) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "No enabled static identities or OAuth profiles are configured.",
                    "Auth Repeater",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int runId = runCounter.incrementAndGet();

        api.logging().logToOutput(
                "Auth Repeater run #" + runId + ": " + originalRequest.method() + " " + url
        );

        worker.submit(() -> executeRun(runId, originalRequest, snapshot, oauthSnapshot));
    }

    private void executeRun(
            int runId,
            HttpRequest originalRequest,
            Environment snapshot,
            List<OAuthProfile> oauthSnapshot
    ) {
        for (Identity identity : snapshot.identities) {
            executeIdentity(
                    runId,
                    originalRequest,
                    snapshot,
                    identity.name,
                    identity.headers
            );
        }

        for (OAuthProfile profile : oauthSnapshot) {
            try {
                String accessToken = validAccessToken(profile);
                Map<String, String> headers = new LinkedHashMap<>();
                headers.put("Authorization", "Bearer " + accessToken);

                executeIdentity(
                        runId,
                        originalRequest,
                        snapshot,
                        profile.name,
                        headers
                );
            } catch (Exception ex) {
                HttpRequest cleanRequest = removeManagedIdentityHeaders(originalRequest, snapshot);

                addResult(
                        runId,
                        profile.name,
                        cleanRequest.method(),
                        safeUrl(cleanRequest),
                        "OAUTH ERROR: " + (ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage()),
                        0,
                        0,
                        cleanRequest,
                        null
                );

                setOAuthError(profile, ex.getMessage());
            }
        }
    }

    private void executeIdentity(
            int runId,
            HttpRequest originalRequest,
            Environment snapshot,
            String identityName,
            Map<String, String> identityHeaders
    ) {
        HttpRequest requestForUser = removeManagedIdentityHeaders(originalRequest, snapshot);

        for (Map.Entry<String, String> header : identityHeaders.entrySet()) {
            requestForUser = requestForUser.withHeader(header.getKey(), header.getValue());
        }

        long start = System.nanoTime();

        try {
            HttpRequestResponse exchange = api.http().sendRequest(requestForUser);
            long elapsedMs = (System.nanoTime() - start) / 1_000_000L;

            if (!exchange.hasResponse() || exchange.response() == null) {
                addResult(
                        runId,
                        identityName,
                        requestForUser.method(),
                        requestForUser.url(),
                        "NO RESPONSE",
                        0,
                        elapsedMs,
                        requestForUser,
                        null
                );
                return;
            }

            HttpResponse response = exchange.response();
            String status = response.statusCode() + " " + response.reasonPhrase();
            int length = response.toByteArray().length();

            addResult(
                    runId,
                    identityName,
                    requestForUser.method(),
                    requestForUser.url(),
                    status.trim(),
                    length,
                    elapsedMs,
                    requestForUser,
                    response
            );
        } catch (Exception ex) {
            long elapsedMs = (System.nanoTime() - start) / 1_000_000L;

            addResult(
                    runId,
                    identityName,
                    requestForUser.method(),
                    safeUrl(requestForUser),
                    "ERROR: " + ex.getClass().getSimpleName(),
                    0,
                    elapsedMs,
                    requestForUser,
                    null
            );

            api.logging().logToError(
                    "Auth Repeater error for " + identityName + ": " + ex.getMessage()
            );
        }
    }

    private HttpRequest removeManagedIdentityHeaders(HttpRequest request, Environment snapshot) {
        HttpRequest clean = request;
        for (String headerName : snapshot.managedHeaderNames) {
            clean = clean.withRemovedHeader(headerName);
        }
        return clean;
    }

    private String safeUrl(HttpRequest request) {
        try {
            return request.url();
        } catch (RuntimeException ex) {
            return "<unparseable URL>";
        }
    }

    private void addResult(
            int run,
            String user,
            String method,
            String url,
            String status,
            int length,
            long elapsedMs,
            HttpRequest request,
            HttpResponse response
    ) {
        SwingUtilities.invokeLater(() -> {
            resultEntries.add(new ResultEntry(
                    run, user, method, url, status, length, elapsedMs, request, response
            ));

            resultsModel.addRow(new Object[]{
                    run,
                    user,
                    method,
                    url,
                    status,
                    length,
                    elapsedMs
            });

            int modelRow = resultsModel.getRowCount() - 1;
            int viewRow = resultsTable.convertRowIndexToView(modelRow);

            if (viewRow >= 0) {
                resultsTable.setRowSelectionInterval(viewRow, viewRow);
            }
        });
    }

    private static final class OAuthProfile {
        final int id;
        String name;
        boolean enabled;
        String accessTokenField;
        String expiresField;
        String refreshTokenField;
        HttpRequest refreshRequest;
        HttpResponse lastResponse;
        String currentAccessToken;
        String currentRefreshToken;
        long expiresAtEpochMs;
        String status;

        OAuthProfile(
                int id,
                String name,
                boolean enabled,
                String accessTokenField,
                String expiresField,
                String refreshTokenField,
                HttpRequest refreshRequest
        ) {
            this.id = id;
            this.name = name;
            this.enabled = enabled;
            this.accessTokenField = accessTokenField;
            this.expiresField = expiresField;
            this.refreshTokenField = refreshTokenField;
            this.refreshRequest = refreshRequest;
            this.status = "Not refreshed";
        }
    }

    private static final class ResultEntry {
        final int run;
        final String user;
        final String method;
        final String url;
        final String status;
        final int length;
        final long elapsedMs;
        final HttpRequest request;
        final HttpResponse response;

        ResultEntry(
                int run,
                String user,
                String method,
                String url,
                String status,
                int length,
                long elapsedMs,
                HttpRequest request,
                HttpResponse response
        ) {
            this.run = run;
            this.user = user;
            this.method = method;
            this.url = url;
            this.status = status;
            this.length = length;
            this.elapsedMs = elapsedMs;
            this.request = request;
            this.response = response;
        }
    }

    private static final class FindingEntry {
        final int id;
        final int run;
        final String method;
        final String url;
        final List<ResultEntry> entries;

        FindingEntry(
                int id,
                int run,
                String method,
                String url,
                List<ResultEntry> entries
        ) {
            this.id = id;
            this.run = run;
            this.method = method;
            this.url = url;
            this.entries = entries;
        }
    }

    private static final class Environment {
        final String scopePrefix;
        final List<Identity> identities;
        final Set<String> managedHeaderNames;

        Environment(
                String scopePrefix,
                List<Identity> identities,
                Set<String> managedHeaderNames
        ) {
            this.scopePrefix = scopePrefix;
            this.identities = List.copyOf(identities);
            this.managedHeaderNames = Set.copyOf(managedHeaderNames);
        }
    }

    private static final class Identity {
        final String name;
        final Map<String, String> headers;

        Identity(String name, Map<String, String> headers) {
            this.name = name;
            this.headers = Map.copyOf(headers);
        }
    }

    private static final class UserEditor {
        final JPanel panel;
        final JCheckBox enabledBox;
        final JTextField nameField;
        final JTextArea headersArea;

        UserEditor(int number) {
            panel = new JPanel(new BorderLayout(8, 8));
            panel.setBorder(BorderFactory.createTitledBorder("User " + number));
            panel.setPreferredSize(new Dimension(700, 145));

            JPanel top = new JPanel(new BorderLayout(8, 8));

            enabledBox = new JCheckBox("Enabled", true);
            nameField = new JTextField("User " + number);

            top.add(enabledBox, BorderLayout.WEST);
            top.add(new JLabel("Name:"), BorderLayout.CENTER);
            top.add(nameField, BorderLayout.EAST);
            nameField.setPreferredSize(new Dimension(240, 26));

            headersArea = new JTextArea(4, 60);
            headersArea.setLineWrap(false);
            headersArea.setToolTipText(
                    "One header per line. Examples: Cookie: session=... or Authorization: Bearer ..."
            );

            JScrollPane headersScroll = new JScrollPane(headersArea);
            headersScroll.setBorder(BorderFactory.createTitledBorder(
                    "Identity headers - one per line (Header-Name: value)"
            ));

            panel.add(top, BorderLayout.NORTH);
            panel.add(headersScroll, BorderLayout.CENTER);
        }
    }
}
