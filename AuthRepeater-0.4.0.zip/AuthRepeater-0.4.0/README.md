# Auth Repeater 0.4.0

Burp Suite Community extension for replaying the same HTTP request with multiple identities and comparing authorization behavior.

## Main features

- Static identities using Cookie, Authorization or custom headers.
- OAuth Profiles based on a real captured refresh-token request.
- Automatic parsing of `access_token`, `expires_in` and rotating `refresh_token` values.
- Refreshes OAuth access tokens 30 seconds before expiry.
- Falls back to the JWT `exp` claim when `expires_in` is not present.
- Results Log with status, length, timing, request and response viewers.
- Manual `Mark as Vulnerable` workflow and Findings tab.

## OAuth workflow

1. Capture the real refresh-token request in Burp Proxy or Repeater.
2. Right-click it and choose **Add as OAuth Refresh Profile...**.
3. Give the profile a name such as `Master OAuth`.
4. The extension sends the captured refresh request and parses the token response.
5. Configure the normal target scope in **Set Environment**.
6. Send an API request to **Auth Repeater**.
7. Enabled OAuth profiles are replayed using `Authorization: Bearer <current access token>`.

Default token response fields:

- Access token: `access_token`
- Expiration: `expires_in`
- Refresh token: `refresh_token`

These field names can be changed per profile.

> Use only on systems you own or are authorized to test.
