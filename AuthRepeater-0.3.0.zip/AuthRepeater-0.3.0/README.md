# Auth Repeater 0.3.0

Burp Suite extension for replaying the same HTTP request with multiple configured user identities and comparing the responses.

## Features

- Configure 3 user identities with `Cookie`, `Authorization`, or custom headers.
- URL-prefix scope.
- **Send to Auth Repeater** context menu.
- Results Log with status, length, and response time.
- Native Burp Request/Response viewers.
- Right-click a result and select **Mark as Vulnerable**.
- **Findings** tab for confirmed vulnerable endpoints.
- Each finding keeps the complete run and lets you switch between each user's Request/Response evidence.

## Build

Requires Java 21 and Montoya API 2026.7.

```bash
gradle clean jar
```

## Load

Burp Suite -> Extensions -> Installed -> Add -> Java

Select:

`AuthRepeater-0.3.0.jar`

## Workflow

1. Configure the scope and identities.
2. Save Environment.
3. Right-click a request -> **Send to Auth Repeater**.
4. Review the responses in **Results Log**.
5. Right-click a confirmed issue -> **Mark as Vulnerable**.
6. Review saved evidence in **Findings**.

Use only on systems you own or have permission to test.
